SMB NES ROM Text Editor v.1.1.0.34394
Programmed by: Shawn M. Crawford [sleepy] 06/25/2010 in C#
---------------------------------------------------------

Features:
	* edit every line of text in the game
	* this version only works with JAP/US rom (Super Mario Bros. (JU) (PRG0) [!].nes.), might work with other versions but untested because it relies on offsets in the ROM

Requires:
	* .Net Framework 3.5, tested with windows 7 64bit and windows vista 32bit

Usage:
	*Open the Rom (Super Mario Bros. (JU) (PRG0) [!].nes.), change text, click update, make sure you have a backup in case something breaks.
	*This is first release so it will probably have bugs, feel free to email bugs to sleepy3d@gmail.com

TODO: refactor...


1.1.0.34394
---------------------------------------------------------
-Fixed a small bug in the punctuation.

1.0.0.18320  06/25/2010
---------------------------------------------------------
-initial release



